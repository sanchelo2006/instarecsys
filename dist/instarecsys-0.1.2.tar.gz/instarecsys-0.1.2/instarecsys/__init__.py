from instarecsys.instarecsys import Insta

print('module instarecsys imported...')